//
//  SceneDelegate.h
//  MyCurrency
//
//  Created by user225081 on 8/14/23.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

